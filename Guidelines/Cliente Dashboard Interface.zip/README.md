
  # Cliente Dashboard Interface

  This is a code bundle for Cliente Dashboard Interface. The original project is available at https://www.figma.com/design/7neJvPiNS8Pfgta72k3nlT/Cliente-Dashboard-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  